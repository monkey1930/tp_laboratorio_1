#include <stdio.h>
#include <stdlib.h>




int mostrarMenu(int x, int y){
int retur = 0;
system("cls");

    printf("   ****MENU****\n\n");
    printf("1_ ingresar primer operando (A=%d)\n", x);
    printf("2_ Ingresar 2do operando (B=%d)\n", y);
    printf("3_ Calcular todas las operaciones\n");
    printf("4_ Informar resultados\n");
    printf("5_ salir\n");


return retur;
}













int pedirOpcion(){
    int opc;
    printf("elija una opcion ");
    fflush(stdin);
    scanf("%d", &opc);
    printf("\n");
    return opc;
}













int ingresarOperando(int* x, char mensaje[]){
int retur;
printf("%s", mensaje);
fflush(stdin);
scanf("%d", x);
if(x != NULL){
    printf("\n operacion realizada con exito...\n\n");
    retur = 1;
}else{
    printf("\n ERROR al realizar la operacion...\n\n");
    retur = 0;
}

return retur;

}





void confirmacionOperacion(int x, int y, char mensaje[], char operacion){

    printf("a_ %s (%d%c%d) fue realizada con exito.\n",mensaje, x, operacion, y);

}









int suma(int x, int y){
int retur = x + y;
return retur;
}




int resta(int x, int y){
int retur = x - y;
return retur;
}




float division(int x, int y){
float retur =(float) x / y;
return retur;
}




int multiplicacion(int x, int y){
int retur = x * y;
return retur;
}






int factorial(int x){

    int resul = 1;

    for(int i = x; i >= 1; i--)
    {
        resul *= i;
    }

    return resul;

}







int realizarOperaciones(int x, int y, int* resulSuma, int* resulResta, float* resulDivision, int* resulMultiplicacion, int* resulFactor1, int* resulFactor2){

int retur = 0;


              *resulSuma = suma(x, y);
              confirmacionOperacion(x, y, "La suma", '+');

              *resulResta = resta(x, y);
              confirmacionOperacion(x, y, "La resta", '-');

              if(y != 0){
              *resulDivision = division(x, y);
              printf("c_ La division (%d/%d) fue realizada con exito.\n", x, y);
                retur = 1;
              }else{
              *resulDivision = 0;
              printf("c_ La division (%d/%d) IMPOSIBLE DIVIDIR POR CERO.\n", x, y);
              }

              *resulMultiplicacion = multiplicacion(x, y);
              confirmacionOperacion(x, y, "La multiplicacion", '*');

              *resulFactor1 = factorial(x);
              *resulFactor2 = factorial(y);
              printf("e_ El factorial de (%d!) y (%d!) fue realizado con exito.\n\n", x, y);

return retur;
}




int mostrarResultados(int x, int y, int resulSuma, int resulResta, float resulDivision, int resulMultiplicacion, int resulFactor1, int resulFactor2){

int retur = 0;
              printf("\na_ La suma (%d+%d) es: %d\n", x, y, resulSuma);
              printf("b_ La resta (%d-%d) es: %d\n", x, y, resulResta);
              if(y != 0){
              printf("c_ La division (%d/%d) es: %.2f\n", x, y, resulDivision);
              retur = 1;
              }else{
              printf("c_ La division (%d/%d) IMPOSIBLE DIVIDIR POR CERO.\n", x, y);
              }
              printf("d_ La multiplicacion (%d*%d) es: %d\n", x, y, resulMultiplicacion);
              printf("e_ El factorial de(%d!) es: %d y el factorial de(%d!) es: %d\n\n", x,resulFactor1, y, resulFactor2);
return retur;

}
