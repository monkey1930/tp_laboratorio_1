#include <stdio.h>
#include <stdlib.h>
#include "trabajo1.h"




int main()
{
    int opc;         ///var usada para guardar la opcion del usuario
    int x = 0;       ///var para guardar el primer operando ingresado
    int y = 0;       ///var para guardar el segundo operando ingresado
    int sumar;       ///var usada para guardar el resultado de suma(x + y)
    int restar;      ///var usada para guardar el resultado de la resta(x - y)
    int multiplicar; ///var usada para guardar el resultado de la muultiplicacion(x * y)
    float dividir;   ///var usada para guardar el resultado de la division(x / y)
    int factorA;     ///var usada para guardar el resultado del factorA(x!)
    int factorB;     ///var usada para guardar el resultado del factorB(y!)
    char seguir;     ///var usada para validar la salida
    int flag1 = 0;
    int flag2 = 0;
    int flag3 = 0;


do{
    mostrarMenu( x, y);
    opc = pedirOpcion();

    switch(opc){

        case 1:
            ingresarOperando(&x, "\ningrese el valor del primer operando(X):");
            system("pause");
            if(flag3 == 1){
                flag3 = 0;
            }
            flag1 = 1;

            break;


        case 2:
            ingresarOperando(&y, "\ningrese el valor del segundo operando(Y):");
            system("pause");
            if(flag3 == 1){
                flag3 = 0;
            }
            flag2 = 1;

            break;


        case 3:
            if(flag1 && flag2){

            realizarOperaciones(x, y, &sumar, &restar, &dividir, &multiplicar, &factorA, &factorB);
            flag3 = 1;

            }else{
                printf("\nIngrese los operandos para acceder a esta opcion.\n\n");
            }
            system("pause");
            break;


        case 4:
            if(flag3 == 1){

                mostrarResultados(x, y, sumar, restar, dividir, multiplicar, factorA, factorB);

            }else{
            printf("\nIngresar los operando y realizar las operaciones para acceder a esta opcion.\n\n");
            }

            system("pause");
            break;
        case 5:
            system("cls");
            printf("usted eligio salir.\n\n");
            printf("oprima s para salir\n");
            fflush(stdin);
            scanf("%c", &seguir);
            break;
        default:
            system("cls");
            printf("\n\nOPCION INVALIDA...\n\n");
            system("pause");
    }
}while(seguir != 's');


    return 0;
}


