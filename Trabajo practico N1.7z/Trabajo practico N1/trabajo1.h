
int mostrarMenu(int x, int y);
int pedirOpcion();
int ingresarOperando(int* x, char mensaje[]);
int suma(int x, int y);
int resta(int x, int y);
float division(int x, int y);
int multiplicacion(int x, int y);
int factorial(int x, int* resultado);
int confirmacionOperacion(int x, int y, char mensaje[], char operacion);
int realizarOperaciones(int x, int y, int* resulSuma, int* resulResta, float* resulDivision, int* resulMultiplicacion, int* resulFactor1, int* resulFactor2);
int mostrarResultados(int x, int y, int resulSuma, int resulResta, float resulDivision, int resulMultiplicacion, int resulFactor1, int resulFactor2);
