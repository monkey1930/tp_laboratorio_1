#include <stdio.h>
#include <stdlib.h>



int ingresarA();
int ingresarB();
int Operaciones(int a, int b);
int mostrarOperaciones(int x[], int tam);
int menuPrincipal();
int sacarfactorial(int x);




int main()
{
int Opciones;
int A;
int B;
int bandera1 = 0;
int bandera2 = 0;
int bandera3 = 0;
int bandera4 = 0;
int resultados[6];


Opciones = menuPrincipal();

if(Opciones == 1)
    {
    A = ingresarA();
    bandera1 = 1;
    }
if(bandera1 && Opciones == 2)
    {
        B = ingresarB();
        bandera2 = 1;

    }
if(bandera2 && Opciones == 3)
    {
    resultados[6] = Operaciones(A, B);
    bandera3 = 1;
    }
if(bandera3 && Opciones == 4)
    {
    mostrarOperaciones(resultados[6], 6);

    }
if(Opciones == 5)
    {
    sistem("cls");

    }


}

int ingresarA()
{
int numA = 0;
printf("ingrese un numerero A ");
scanf("%d", &numA);
return numA;
}

int ingresarB()
{
int numB = 0;
printf("ingrese otro numerero B ");
scanf("%d", &numB);
return numB;
}

int Operaciones(int a, int b)
{
int suma;
int resta;
int division;
int multiplicacion;
int factorialA;
int factorialB;
int respuestas[6];

suma = a + b;
resta = a - b;
division = a / b;
multiplicacion = a * b;
factorialA = sacarfactorial(a);
factorialB = sacarfactorial(b);

respuestas[6] = (suma, resta, division, multiplicacion, factorialA, factorialB);

return respuestas;

}

int mostrarOperaciones(int x[],int tam)
{
   printf("los resultados de las operaciones son: n\ ");
   printf("suma, resta, division, multiplicacion, factorialA, factorialB n\ ");
   printf(x[tam]);
}


int sacarfactorial(int x)
{
int fac = 1;
int i = x;
for(i , i > 0, i-- )
{
fac = fac * i;
}
return fac;
}


int menuPrincipal()
{
int Rta = 0;

do
{
    if(Rta > 5)
    {
         sistem("cls");
         printf("n\ **** opcion no valida **** n\");
    }
printf("n\*****Menu Principal***** n\");

printf("n\opcion uno ni pinshe idea n\");
printf("opcion dos ni pinshe idea n\");
printf("opcion tres ni pinshe idea n\");
printf("opcion cuatro ni pinshe idea n\");
printf("opcion cinco ni pinshe idea n\");
printf("----seleccione una opcion---- n\");

scanf("%d", &Rta);

}while(Rta > 5 || Rta < 1)

return Rta;

}

