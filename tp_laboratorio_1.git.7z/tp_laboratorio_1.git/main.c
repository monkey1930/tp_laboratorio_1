#include <stdio.h>
#include <stdlib.h>
#include <string.h>




int ingresarA();
int ingresarB();
int Operaciones(int a, int b);
void mostrarOperaciones(int x[], int tam);
int menuPrincipal();
int sacarfactorial(int x);




int main()
{
int Opciones;
int A;
int B;
int bandera1 = 0;
int bandera2 = 0;
int bandera3 = 0;
int resultados[6];

do{
Opciones = menuPrincipal();
switch(Opciones)
{

case 1:
    if(Opciones == 1)
    {
    A = ingresarA();
    bandera1 = 1;
    }
break;

case 2:
    if(bandera1 && Opciones == 2)
    {
        B = ingresarB();
        bandera2 = 1;

    }
    else
        {
        printf("primero debe cargar A");
        }
break;
case 3:
    if(bandera2 && Opciones == 3)
    {

    resultados[6] = Operaciones(A, B);
    bandera3 = 1;
    }
     else
        {
        printf("primero debe cargar A y B");
        }
break;
case 4:
    if(bandera3 && Opciones == 4)
    {
    mostrarOperaciones(resultados, 6);

    }
    else
        {
        printf("primero debe cargar A , B y hacer las operaciones");
        }
break;
default:
    printf("Programa terminado....");


}
}while(Opciones != 5);
/*
Opciones = menuPrincipal();


Opciones = menuPrincipal();


 Opciones = menuPrincipal();



Opciones = menuPrincipal();


Opciones = menuPrincipal();
if(Opciones == 5)
    {
    printf("Programa terminado....");
    }*/

return 0;
}

int ingresarA()
{
int numA = 0;
printf("ingrese un numerero A ");
scanf("%d", &numA);
return numA;
}

int ingresarB()
{
int numB = 0;
printf("ingrese otro numerero B ");
scanf("%d", &numB);
return numB;
}

int Operaciones(int a, int b)
{
int suma;
int resta;
int division;
int multiplicacion;
int factorialA;
int factorialB;

suma = a + b;
resta = a - b;
division = a / b;
multiplicacion = a * b;
factorialA = sacarfactorial(a);
factorialB = sacarfactorial(b);

int respuestas[6] = {suma, resta, division, multiplicacion, factorialA, factorialB};

return respuestas;

}

void mostrarOperaciones(int x[], int tam)
{
int i;

   printf("los resultados de las operaciones son: n\ ");
   printf("suma, resta, division, multiplicacion, factorialA, factorialB n\ ");
   for(i= 0; i > tam; i++)
    {
    printf("\n %d", x[i]);

    }
}


int sacarfactorial(int x)
{
int fac = 1;
int i;
for(i = x; i > 0; i-- )
{
fac = i * fac;
}
return fac;
}


int menuPrincipal()
{
int Rta = 0;

do
{
    if(Rta > 5)
    {
         system("cls");
         printf(" \n*** opcion no valida **** n\ " );

    }

printf("\n*****Menu Principal***** \n");

printf("\nopcion uno " );
printf("\nopcion dos  ");
printf("\nopcion tres  ");
printf("\nopcion cuatro ");
printf("\nopcion cinco  \n");
printf("\n----seleccione una opcion---- \n");

scanf("%d", &Rta);

}while(Rta > 5 || Rta < 1);

//return Rta;
return Rta;
}

