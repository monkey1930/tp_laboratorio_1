#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn_eEmpleados.h"



int inicializar_Empleados(eEmpleado vec[], int tam){
int ret = 0;
for(int i=0; i < tam; i++)
{
vec[i].id = 0;
strcpy(vec[i].name, "");
strcpy(vec[i].lastName, "");
vec[i].salary = 0;
vec[i].sector = 0;
vec[i].isEmpty = 0;
ret = 1;
}
return ret;
}



int mostrar_Empleado(eEmpleado emp){
    int ret = 1;
if(emp.isEmpty == 1)
printf("%d     %10s        %10s      %.2f       %d      %d   \n", emp.id, emp.name, emp.lastName, emp.salary, emp.sector, emp.isEmpty);
if(emp.isEmpty == 0)
ret = 0;

return ret;
}


int mostrar_Empleados(eEmpleado vec[], int tam){

printf("ID        Nombre      APELLIDO      SALARIO     SECTOR     ESTADO   \n\n");
int ret = 0;
for(int i=0; i<tam; i++){

if(vec[i].isEmpty == 1)
    {
mostrar_Empleado(vec[i]);
ret = 1;
    }
}
if(ret == 0)
    printf("NO HAY EMPLEADOS CARGADOS...\n\n");

return ret;
}


int buscarLibre(eEmpleado vec[], int tam){
int i;
for( i = 0; i<tam; i++){
    if(vec[i].isEmpty == 0)
        break;
}
if(vec[i].isEmpty != 0)
    i=-1;
return i;
}



int cargarEmpleado(eEmpleado vec[], int tam, eSector vec_sec[], int tam_sec){

int index = buscarLibre(vec, tam);
int ret = -1;
if(index != -1 && tam > 0){
    vec[index].id = index + 1001;

    printf("\n\ningrese el nombre: ");
    fflush(stdin);
    gets(vec[index].name);

    printf("\n\ningrese el apellido: ");
    fflush(stdin);
    gets(vec[index].lastName);

    printf("ingrese el sueldo: ");
    fflush(stdin);
    scanf("%f", &vec[index].salary);

    vec[index].sector = selec_sector(vec_sec, tam_sec);

    vec[index].isEmpty = 1;
    ret = 1;
}
else{
        printf("\n\nnumero de empleados maximos alcanzado...\n\n");
}
return ret;
}


int buscar_Empleado_id(eEmpleado vec[], int tam, int id){
    int ret = -1;
for(int i=0; i<tam; i++){

    if(vec[i].id == id){
        ret = i;
        break;
    }
}
return ret;
}


int baja_Empleado(eEmpleado vec[], int tam){
int id;
int index;
char seguir;
if(mostrar_Empleados(vec, tam) == 1){
printf("\ningrese la ID del empleado a dar de baja:  ");
scanf("%d", &id);

index = buscar_Empleado_id(vec, tam, id);
if(index != -1){
printf("\nESTA SEGURO DE DAR DE BAJA AL SIGUIENTE EMPLEADO....\n");
mostrar_Empleado(vec[index]);

            printf("\noprima s para confirmar\n");
            fflush(stdin);
            scanf("%c", &seguir);
            if(seguir == 's'){

                vec[index].isEmpty = 0;
            }

}else{
printf("\n\nERROR AL BUSCAR EMPLEADO, Id no valida");
}

}

return 1;
}





int pedirOpcion(){
    int opc;
    printf("elija una opcion ");
    fflush(stdin);
    scanf("%d", &opc);
    printf("\n");
    return opc;
}



int selec_sector(eSector vec[], int tam){

int id_sector = 0;
do{
if(id_sector > tam)
printf("ingrese una id valida...\n");
printf("SECTORES...\n");
for(int i=0; i<tam; i++){
printf("%d        %s\n", vec[i].id, vec[i].descripcion);
}
id_sector = pedirOpcion();
}while(id_sector > tam);

return id_sector;
}


void ordenamiento_alf_sec(eEmpleado vec[], int tam, int ordenamiento){

eEmpleado aux_emp;

for(int i=0; i<tam-1; i++){

    for(int j=i+1; j<tam; j++){

        if(ordenamiento == 1 && vec[i].isEmpty == 1 && comparacion(vec[i].lastName[0], vec[j].lastName[0]) > 0)
            {

                        aux_emp = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux_emp;


            }

        if(ordenamiento == 0 && vec[i].isEmpty == 1 && comparacion(vec[i].lastName[0], vec[j].lastName[0]) < 0)
            {

                        aux_emp = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux_emp;


            }
            if(ordenamiento == 0 && vec[i].isEmpty == 1 && comparacion(vec[i].lastName[0], vec[j].lastName[0]) == 0)
            {
                if(vec[i].sector < vec[j].sector)
                    {
                        aux_emp = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux_emp;

                    }
            }

    }
}

}

int comparacion(char letra1, char letra2){
int retor;
if(letra1 < letra2)
    retor = -1;
if(letra1 > letra2)
    retor = 1;
if(letra1 == letra2)
    retor = 0;

    return retor;
}


int segundo_informe(eEmpleado vec[], int tam, float* salary_total, float* salary_promedio, int* cont_emp_mayor_prom){

float acumulador = 0;
int cont = 0;
int cont_emp = 0;
for(int i=0; i<tam; i++)
    {
    if(vec[i].isEmpty > 0){
    acumulador += vec[i].salary;
    cont ++;
    }
    }
*salary_promedio = acumulador / cont;
*salary_total = acumulador;
for(int i=0; i<tam; i++)
    {
    if(vec[i].isEmpty > 0 && vec[i].salary > (acumulador / cont))
    cont_emp++;
    }
*cont_emp_mayor_prom = cont_emp;

return cont_emp;
}


int pedir_String(char str[], char mensaje[]){
printf("%s", mensaje);
fflush(stdin);
gets(str);


return (strlen(str));
}


int elegir_emp_byId(eEmpleado vec[], int tam){
int id;
int index;
printf("Empleados cargados...\n");
mostrar_Empleados(vec, tam);
printf("ingrese la id del empleado: ");
scanf("%d", &id);
index = buscar_Empleado_id(vec, tam, id);
if(index == -1)
    printf("error al ingresar la id");
return index;
}

float pedir_Float(float* decimal, char mensaje[]){
printf("%s", mensaje);
fflush(stdin);
scanf("%f", decimal);



return *decimal;
}
