#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn_eEmpleados.h"
#define  TAM_EMP 2
#define  TAM_SEC 2




int mostrarMenu();
int pedirOpcion();



int main()
{
    int opc2; ///temporal

    eEmpleado emp_list[TAM_EMP] = {  {1, "ariel","fafa",1000,1,1},
                                     {2, "josepaz","fafa",11230,2,1}   };
    eSector sec_list[TAM_SEC] = {{1, "sector A"}, {2, "sector B"}};
    //inicializar_Empleados(emp_list, TAM_EMP);

    int opc;
    char seguir;
    int cont;
    float salary_total;
    float salary_promedio;
    int index;



do{
    mostrarMenu();
    opc = pedirOpcion();
    switch(opc){

        case 1:
            cargarEmpleado(emp_list, TAM_EMP, sec_list, TAM_SEC);
            system("pause");
            break;

        case 2:
            printf("\n\nproximamente.... :) \n\n");
            printf("1_ modificar nombre\n");
            printf("2_ modificar apellido\n");
            printf("3_ modificar salario\n");
            printf("4_ modificar sector\n");
            opc2 = pedirOpcion();

            switch(opc2)
                {
                case 1:
                    index = elegir_emp_byId(emp_list, TAM_EMP);
                    pedir_String(emp_list[index].name, "ingresar el nuevo nombre: ");
                    break;
                case 2:
                    index = elegir_emp_byId(emp_list, TAM_EMP);
                    pedir_String(emp_list[index].lastName, "ingresar el nuevo apellido: ");
                    break;
                case 3:
                    index = elegir_emp_byId(emp_list, TAM_EMP);
                    pedir_Float()
                    break;
                case 4:
                    break;
                default:
                    printf("opcion no valida\n");
                }


            system("pause");
            break;

        case 3:
            baja_Empleado(emp_list, TAM_EMP);
            system("pause");
            break;

        case 4:
            mostrar_Empleados(emp_list, TAM_EMP);
            ordenamiento_alf_sec(emp_list, TAM_EMP, ACENDENTE );
            mostrar_Empleados(emp_list, TAM_EMP);

            printf("\n\n\n\n");

            segundo_informe(emp_list, TAM_EMP, &salary_total, &salary_promedio, &cont);

            printf("suma de todos los salarios: %.2f\npromedio de todos los salarios: %.2f\ncantidad de salarios mayores al promedio: %d\n", salary_total, salary_promedio, cont);


            system("pause");
            break;

        case 5:
            system("cls");
            printf("usted eligio salir.\n\n");
            printf("oprima s para salir\n");
            fflush(stdin);
            scanf("%c", &seguir);
            break;
        default:
            system("cls");
            printf("\n\nOPCION INVALIDA...\n\n");
            system("pause");
    }

}while(seguir != 's');

    return 0;
}

int mostrarMenu(){
int retur = 0;
system("cls");

    printf("   ****MENU****\n\n");
    printf("1_ Cargar empleado\n");
    printf("2_ Modificar empleado\n");
    printf("3_ Baja empleado\n");
    printf("4_ Informar\n");
    printf("5_ salir\n");


return retur;
}





