#define ACENDENTE 1
#define DECENDIENTE 0

typedef struct{
int id;
char name[51];
char lastName[51];
float salary;
int sector;
int isEmpty;
}eEmpleado;

typedef struct{
int id;
char descripcion[51];
}eSector;



int pedirOpcion();
int inicializar_Empleados(eEmpleado vec[], int tam);

int mostrar_Empleado(eEmpleado emp);
int mostrar_Empleados(eEmpleado vec[], int tam);

int buscarLibre(eEmpleado vec[], int tam);

void ordenamiento_alf_sec(eEmpleado vec[], int tam, int ordenamiento);
int cargarEmpleado(eEmpleado vec[], int tam, eSector vec_sec[], int tam_sec);

int baja_Empleado(eEmpleado vec[], int tam);
int buscar_Empleado_id(eEmpleado vec[], int tam, int id);

int selec_sector(eSector vec[], int tam);
int segundo_informe(eEmpleado vec[], int tam, float* salary_total, float* salary_promedio, int* cont_emp_mayor_prom);
int comparacion(char letra1, char letra2);

int pedir_String(char str[], char mensaje[]);
int elegir_emp_byId(eEmpleado vec[], int tam);
float pedir_Float(float* decimal, char mensaje[]);
